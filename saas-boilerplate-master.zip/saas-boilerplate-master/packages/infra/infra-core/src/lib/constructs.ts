import { EnvironmentSettings } from './env-config';

export interface EnvConstructProps {
  envSettings: EnvironmentSettings;
}
