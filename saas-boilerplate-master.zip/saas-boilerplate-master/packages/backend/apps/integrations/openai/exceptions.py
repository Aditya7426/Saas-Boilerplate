class OpenAIClientException(Exception):
    pass
