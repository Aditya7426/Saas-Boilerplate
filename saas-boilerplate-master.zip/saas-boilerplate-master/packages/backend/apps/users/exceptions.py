from common.exceptions import DomainException


class OTPVerificationFailure(DomainException):
    pass
