export interface ToolsGeneratorSchema {
  name: string;
  tags?: string;
  directory?: string;
}
