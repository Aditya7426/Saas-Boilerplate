export interface WebappLibGeneratorSchema {
  name: string;
  tags?: string;
  directory?: string;
}
